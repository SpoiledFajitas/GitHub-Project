package Mod;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class userBank {


    private static ArrayList<User> users = new ArrayList();

    public userBank() {

    }
    
    public int numUsers() {
    	return users.size();
    }
    
    public String returnUsersNames() {
    	String t = "";
    	for(int i =0; i<users.size(); i++) {
    		t += users.get(i).getUsername();
    	}
    	return t;
    }
    
    public boolean moreThanZeroUsers() {
    	return users.size()>0;
    }

    public void addNewUser(String uName, String pass){
        users.add(new User(uName, pass));
    }

    public User findUser(String uName){
        for(int i =0; i<users.size(); i++){
            if(users.get(i).getUsername().equals(uName)){
                return users.get(i);
            }
        }
        return null;
    }

    public boolean checkUsername(String uName){
        if(findUser(uName) == null){
            return false;
        }
        return true;
    }

    public boolean checkCorrectPasswrd(String uName, String passW){
        if(checkUsername(uName)){
            if(findUser(uName).getPassword().equals(passW)){
                return true;
            }
            return false;
        }
        return false;
    }
}
