package Mod;

import java.util.ArrayList;

public class User {




    private ArrayList<condition>  conditions = new ArrayList<>();
    private int hoursOfSleep = 0;
    private int age = 0;
    private String username;
    private String password;
    private int feetHeight;
    private int inchheight;
    private double weight;

    public boolean alreadyThereCond(String c) {
    	for(int i =0; i<conditions.size(); i++) {
    		if(conditions.get(i).getName().equals(c)) {
    			return true;
    		}
    	}
    	return false;
    }
    
    public void setHoursOfSleep(int n) {
    	hoursOfSleep = n;
    }
    
    public int getHoursOfSleep() {
    	return hoursOfSleep;
    }
    
    public User(String u, String p) {
        username = u;
        password = p;
    }

    public void setAge(int setA){
        age = setA;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void addCondition(condition cond){
        conditions.add(cond);
    }
    
    public void setFeet(int h) {
    	feetHeight = h;
    }
    
    public void setInch(int h) {
    	inchheight = h;
    }
    
    public void setWeight(double h) {
    	weight = h;
    }
    
    public double getWeight() {
    	return weight;
    }
    
    public int getFeet() {
    	return feetHeight;
    }
    
    public int getAge() {
    	return age;
    }
    
    public int getInch() {
    	return inchheight;
    }
    
    public String retConditionNames() {
    	String ret = "";
    	for(int i =0; i<conditions.size(); i++) {
    		ret += conditions.get(i).getName();
    		ret += " and ";
    	}
    	return ret;
    }
    
    public int retConditionTimeAdd() {
    	int ret = 0;
    	for(int i =0; i<conditions.size(); i++) {
    		ret += conditions.get(i).getHourIncrease();
    	}
    	return ret;
    }
    
    public String retConditionTips() {
    	String ret = "";
    	for(int i =0; i<conditions.size(); i++) {
    		ret += conditions.get(i).getName();
    		ret += ": ";
    		ret += conditions.get(i).getTip();
    		ret += "\n";
    	}
    	return ret;
    }
    
    
    public boolean isObese() {
    	double weightKg = 0.45359237* weight;
    	double heightM = (0.3048* feetHeight)+ (0.0254 *inchheight);
    	return weightKg/(heightM*heightM) >25;
    }
}

