package Mod;

public class condition {

    private String name;
    private String tip;
    private int hourIncrease;

    public condition(String n, String t, int inc){
        name = n;
        tip = t;
        hourIncrease = inc;
    }
    
    public String getName() {
    	return name;
    }
    public String getTip() {
    	return tip;
    }
    public int getHourIncrease() {
    	return hourIncrease;
    }



}