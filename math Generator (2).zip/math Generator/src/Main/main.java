package Main;
import javax.swing.SwingUtilities;

import Mod.GradeChooser;
import Mod.problemSelect;

//Main class of the program starts the program
public class main {

	//Main method of the program. Runs the program
	public static void main(String[] args) {
		
		System.out.println("hi");
		GradeChooser o = new GradeChooser();
		o.setVisible(true);
		o.isVisible();
	}
}
